public class Main{
    public static void main(String []args){
        Window s = new Window(30);
        s.setVisible(true);
    }
}